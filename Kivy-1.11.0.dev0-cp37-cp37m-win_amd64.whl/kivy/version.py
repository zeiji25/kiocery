# THIS FILE IS GENERATED FROM KIVY SETUP.PY
__version__ = '1.11.0.dev0'
__hash__ = '3b70b7d7bf562755e889a50833c5fece80629167'
__date__ = '20190505'
